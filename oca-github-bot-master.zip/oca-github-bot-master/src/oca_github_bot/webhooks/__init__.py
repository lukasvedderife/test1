# Copyright (c) ACSONE SA/NV 2018
# Distributed under the MIT License (http://opensource.org/licenses/MIT).

from . import (
    on_command,
    on_pr_close_delete_branch,
    on_pr_green_label_needs_review,
    on_pr_open_label_new_contributor,
    on_pr_open_mention_maintainer,
    on_pr_review,
    on_push_to_main_branch,
    on_status_merge_bot,
)

#. Go to *Inventory / Configuration / Settings* and check the option
   'Multi-Step Routes' and press the 'Save' button.
#. Activate the developer mode.
#. Go to *Inventory / Configuration / Warehouse Management / Routes*
   and select the route you want to change. Select the pull rule you wish
   to change and Select 'Propagation of Procurement Group': 'Propagage'.
   The checkbox 'Auto-create Procurement Group' will then appear and you can
   set it if you want to procurement group to be automatically created.

If you configured a "Maximum Discrepancy Rate Threshold".

#. When validating an Inventory Adjustment if some line exceed the Discrepancy
   Threshold the system will set the inventory's state to 'Pending to Approve'
   and show the quantity of lines that exceed the threshold.
#. If both WH and location thresholds are configured, the location one has
   preference.
#. The user with "Validate All inventory Adjustments" rights can force the
   validation of an inventory pending to approve.

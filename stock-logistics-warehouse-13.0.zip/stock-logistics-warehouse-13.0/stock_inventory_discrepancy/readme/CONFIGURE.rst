#. Go to "Inventory > Warehouse Management" > Warehouses" or to "Inventory >
   Warehouse Management" > Locations".
#. Modify the "Maximum Discrepancy Rate Threshold" either in a Warehouse or
   in a location. If set to 0.0 in both the threshold is disabled.

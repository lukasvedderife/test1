To enable preset reason feature, you must:

- Go to: Inventory > Settings > Inventory Adjustment
- Enable: Preset Change Qty Reason
- Enable: Technical Settings > Manage Stock Change Qty Preset Reasons

Once is activate you will require te add a Preset reason to validate stock
products change quantity.


To allow an Stock Manager configure preset reasons easily, you should:

- Select Stock Manager user on: Settings > Users
- Enable: Technical Settings > Manage Stock Change Qty Preset Reasons
- Go to Inventory > Configuration > Inventory Adjustment > Change Qty Reasons

This module extends the product stock management and allows to set a reason
in inventory adjustments globally or per line.

It also can manage preset reasons optionally.

This module lets you include non-stocked products to your inventory.

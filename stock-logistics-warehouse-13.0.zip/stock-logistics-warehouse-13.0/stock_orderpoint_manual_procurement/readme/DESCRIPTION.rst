This module allows users to manually start procurements from the list of reordering rules,
based on the quantity that is recommended to be procured.

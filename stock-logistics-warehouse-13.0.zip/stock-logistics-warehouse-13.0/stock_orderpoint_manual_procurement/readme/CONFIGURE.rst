If you want users to be able to change the recommended quantity to procure,
you should assign them to the security group
'Change quantity in manual procurements from reordering rules',
under 'Settings / Users / Users'.

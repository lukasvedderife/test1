Go to 'Inventory > Master Data > Reordering Rules' and review the quantity recommended to be procured.
You can now start the procurement for a single or a list of reordering rules.

The recommended quantity to procure is adjusted to the
procurement unit of measure indicated in the reordering rule.

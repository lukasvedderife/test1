* The stock manager can check the journal items by accessing to 'Inventory >
  Reports > Stock moves'.

* A user belonging to the group 'Show Full Accounting Features' can review the
  details of a move that is associated to a journal item through
  'Invoicing > Accounting > Journal Entries (or Journal items)'.

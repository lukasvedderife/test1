Adds a reason code for scrapping operations and an interface for the user
to create scrap codes

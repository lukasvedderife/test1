- Go to Inventory > Operations > Scrap
- Create a scarp order and select reason code.
- A scrap location will be readonly and auto fill based on selected reason
  code.

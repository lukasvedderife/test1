This module allows to move entire location of products from one place to
another and move only selected quants.

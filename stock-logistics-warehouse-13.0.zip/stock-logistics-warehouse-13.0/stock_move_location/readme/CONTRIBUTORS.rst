* Mathieu Vatel <mathieu@julius.fr>
* Mykhailo Panarin <m.panarin@mobilunity.com>
* Sergio Teruel <sergio.teruel@tecnativa.com>
* Joan Sisquella <joan.sisquella@forgeflow.com>
* Jordi Ballester Alomar <jordi.ballester@forgeflow.com>
* Lois Rilo <lois.rilo@forgeflow.com>
* Héctor Villarreal <hector.villarreal@forgeflow.com>

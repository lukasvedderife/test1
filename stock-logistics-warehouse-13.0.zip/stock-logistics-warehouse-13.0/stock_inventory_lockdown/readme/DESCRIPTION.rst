This module lets you lock down the locations during an inventory.

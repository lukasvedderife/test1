While an inventory is in the state "In progress", no stock moves
can be recorded in/out of the inventory's location: users will get an error
message.
Creating or modifying locations is also forbidden.

.. figure:: static/images/move_error.png
   :alt: Error message


This module enhances the views associated to account moves and account move
lines to display the product that is associated to the move line.

This will be relevant in perpetual inventory, for inventory-related account
moves.

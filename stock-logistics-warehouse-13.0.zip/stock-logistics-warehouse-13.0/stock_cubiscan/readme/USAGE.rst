Use the "Wizard" button on a Cubiscan device to open the screen and take
measurements.

For developers: a script in the directory ``scripts/cubiscan_stub.py`` allows
to simulate a Cubiscan server and send random measurements.

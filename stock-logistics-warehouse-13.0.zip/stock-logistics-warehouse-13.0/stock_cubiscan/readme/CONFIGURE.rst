The first step is to configure the Packaging Types (Pallet, Box, ...) in Inventory > Configuration > Product Packaging Types.

Configure the Cubiscan device in Inventory > Configuration > Cubiscan Devices.
Use the "Test Device" to check the connection with the hardware.

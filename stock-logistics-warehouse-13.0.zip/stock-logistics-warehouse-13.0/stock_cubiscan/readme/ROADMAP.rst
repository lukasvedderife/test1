* The UI could get some improvements
* Being able to open the Cubiscan screen from a product would be nice

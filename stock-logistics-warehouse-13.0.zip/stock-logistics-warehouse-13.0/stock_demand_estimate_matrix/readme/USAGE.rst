Go to *Inventory > Configuration > Date Ranges* and define your estimating periods.

Go to *Inventory > Demand Planning > Create Demand Estimates* to create or
update your demand estimates.

Go to *Inventory > Demand Planning > Demand Estimates* to review the
estimates created.

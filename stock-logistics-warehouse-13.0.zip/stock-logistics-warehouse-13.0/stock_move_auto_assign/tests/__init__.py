from . import test_auto_assign

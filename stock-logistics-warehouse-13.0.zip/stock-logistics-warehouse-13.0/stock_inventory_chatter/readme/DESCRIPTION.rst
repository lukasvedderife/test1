This module adds the capability to log the changes being done in Inventory Adjustments.

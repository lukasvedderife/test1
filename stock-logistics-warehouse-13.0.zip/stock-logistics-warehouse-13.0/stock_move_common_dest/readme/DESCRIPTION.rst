This module adds a M2m field `common_dest_move_ids` on `stock.move` in order
to compute all the moves having a chained destination move sharing the same
picking as the actual move's destination move.

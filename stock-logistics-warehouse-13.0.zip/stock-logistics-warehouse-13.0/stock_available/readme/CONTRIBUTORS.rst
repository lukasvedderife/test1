* `Numérigraphe <https://www.numerigraphe.com>`_:

    * Lionel Sausin <ls@numerigraphe.com>

* `Sodexis <https://www.Sodexis.com>`_:

    * Sodexis <sodexis@sodexis.com>

* `Factor Libre <https://www.factorlibre.com>`_:

    * Kiko Peiro <francisco.peiro@factorlibre.com>

* `Tecnativa <https://www.tecnativa.com>`_:

    * Sergio Teruel <sergio.teruel@tecnativa.com>

* `Ecosoft <http://ecosoft.co.th/>`_:

    * Pimolnat Suntian <pimolnats@ecosoft.co.th>

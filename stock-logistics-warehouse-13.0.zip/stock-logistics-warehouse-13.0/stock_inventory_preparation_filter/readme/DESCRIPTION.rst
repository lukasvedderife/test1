Includes more options for making an inventory out of:

* Products filtered by a domain.
* Products of a category.
* Multiple lots
